// pages/viewReport/viewReport.js
import req from '../../utils/service.js'
import util from '../../utils/util.js'

Page({

  /**
   * 页面的初始数据
   */
  data: {
    shareId: '',
    report: {}
  },
  getReportInfo: function() {
    var that = this
    req.getRequest('eye/reports/' + this.data.shareId).then(res => {
      if (res === 'loginSuccess') {
        that.getReportInfo()
        return
      }
      var examineTypeStr = res.data.returnObject.examineType == 2 ? '眼前节' : '眼底'
      var reportTypeStr = res.data.returnObject.reportType == 1 ? '咨询报告' : res.data.returnObject.reportType == 2 ? '会诊报告' : '诊断报告'
      wx.setNavigationBarTitle({
        title: examineTypeStr + reportTypeStr,
      })
      res.data.returnObject.admissionNo = res.data.returnObject.admissionNo != null ? res.data.returnObject.admissionNo : ''
      res.data.returnObject.bedNo = res.data.returnObject.bedNo != null ? res.data.returnObject.bedNo : ''
      res.data.returnObject.eyeRightVision = res.data.returnObject.eyeRightVision != null ? res.data.returnObject.eyeRightVision : ''
      res.data.returnObject.eyeLeftVision = res.data.returnObject.eyeLeftVision != null ? res.data.returnObject.eyeLeftVision : ''
      if (res.data.returnObject.eyeLeftImg) {
        var eyeLeftImgArr = res.data.returnObject.eyeLeftImg.split(',')
        for (var i in eyeLeftImgArr) {
          eyeLeftImgArr[i] = util.download(eyeLeftImgArr[i])
        }
        res.data.returnObject.eyeLeftImgArr = eyeLeftImgArr
      }
      if (res.data.returnObject.eyeRightImg) {
        var eyeRightImgArr = res.data.returnObject.eyeRightImg.split(',')
        for (var i in eyeRightImgArr) {
          eyeRightImgArr[i] = util.download(eyeRightImgArr[i])
        }
        res.data.returnObject.eyeRightImgArr = eyeRightImgArr
      }
      that.setData({
        report: res.data.returnObject
      })
    })

  },
  previewImage: function(event) { 
    var src = event.currentTarget.dataset.src; //获取data-src
    var imgList = event.currentTarget.dataset.list; //获取data-list
      //图片预览
    wx.previewImage({  
      current: src, // 当前显示图片的http链接
        urls: imgList // 需要预览的图片http链接列表
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    var that = this;
    that.setData({
      shareId: options.shareId, // options为页面路由过程中传递的参数
    })
    that.getReportInfo()
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {

  }
})