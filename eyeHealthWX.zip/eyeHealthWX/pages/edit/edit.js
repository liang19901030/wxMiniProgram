// pages/edit/edit.js
import util from '../../utils/util.js'
import req from '../../utils/service.js'

var app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    changeType: '',
    title: '',
    userName: '', // 用户姓名
    userIdNumber: '', //用户身份证号
  },

  setIdNumber: function(e) {
    var val = e.detail.value;
    this.setData({
      userIdNumber: val
    });

  },

  setName: function(e) {
    var val = e.detail.value;
    this.setData({
      userName: val
    });

  },
  validateIdNumber: function () {
    var idNumberReg = /(^\d{15}$)|(^\d{18}$)|(^\d{17}(\d|X|x)$)/
    if (!idNumberReg.test(this.data.userIdNumber)) {
      return false
    }
    return true
  },
  done: function() {
    var that = this
    var user = wx.getStorageSync('terryUser')
    var name = user.name
    var avatar = user.avatar
    var idCard = user.idCard
    if (this.data.changeType == 0) {
      if (this.data.userName == '') {
        wx.showToast({
          title: '请填写您的姓名',
          icon: 'none',
          duration: 2000
        })
        return;
      }
      name = this.data.userName
    } else {
      if (!this.validateIdNumber()) {
        wx.showToast({
          title: '请填写正确的身份证号',
          icon: 'none',
          duration: 2000
        })
        return;
      }
      idCard = this.data.userIdNumber
    }
    req.putRequest('patients', {
      name: name,
      idCard: idCard,
      avatar: avatar
    }).then(res => {
      if (res === 'loginSuccess') {
        that.done()
        return
      }
      res.data.returnObject.accessToken = user.accessToken
      wx.setStorageSync('terryUser', res.data.returnObject)
      wx.navigateBack({
        delta: 1
      })
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    var that = this;
    that.setData({
      changeType: options.type //options为页面路由过程中传递的参数
    })
    if (this.data.changeType == 1) {
      that.setData({
        title: '更改身份证号',
        userIdNumber: options.IdNumber
      })
    } else {
      that.setData({
        title: '更改姓名',
        userName: options.name
      })
    }
    wx.setNavigationBarTitle({
      title: that.data.title,
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {

  }
})