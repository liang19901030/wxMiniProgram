// pages/order/order.js
import format from '../../utils/format.js'
import req from '../../utils/service.js'
import util from '../../utils/util.js'

Page({

  /**
   * 页面的初始数据
   */
  data: {
    cityArray: [],
    hospitalArray: [],
    selectedCity: {},
    selectedHospital: {},
    customItem: '全部',
    hospitalName: '洛阳市眼科医院',
    selectMember: {},
    selectedDoctor: {},
    selectedDate: '',
    currentDate: '',
    currentWeek: '',
    dateArray: [],
    doctorList: [],
    toView: 'red',
    scrollTop: 0,
    second_height: 0,
    hideHeader: true,
    refreshTime: '', // 刷新的时间 

  },
  getCity: function() {
    var that = this
    req.getRequest('registeres/citys', {}).then(res => {
      if (res === 'loginSuccess') {
        that.getCity()
        return
      }
      this.setData({
        cityArray: res.data.returnObject
      })
      var selectedCity = this.data.cityArray[0]
      this.setData({
        selectedCity: selectedCity
      })
      that.getHospital(selectedCity.cityCode)
    })
  },
  getHospital: function(cityCode) {
    var that = this
    req.getRequest('registeres/hospitals/' + cityCode).then(res => {
      if (res === 'loginSuccess') {
        that.getHospital()
        return
      }
      this.setData({
        hospitalArray: res.data.returnObject
      })
      var selectedHospital = this.data.hospitalArray[0]
      that.setData({
        selectedHospital: selectedHospital
      })
      that.getDoctorList(that.data.selectedDate)
    })
  },
  getServerTime: function() {
    var that = this
    req.getRequest('times', {}).then(res => {
      if (res === 'loginSuccess') {
        that.getServerTime()
        return
      }
      var timestamp = res.data.returnObject
      that.dealDate(timestamp)
      that.getCity()
    })
  },
  dealDate: function(timestamp) {
    var nowDate = new Date(timestamp);
    var tempDate = new Date(timestamp);
    var year = nowDate.getFullYear();
    var month = nowDate.getMonth() + 1 > 9 ? (nowDate.getMonth() + 1) : '0' + (nowDate.getMonth() + 1);
    var day = nowDate.getDate() > 9 ? nowDate.getDate() : '0' + nowDate.getDate();
    var currentDate = month + '月' + day + '日'
    var currentWeek = '星期' + format.getWeek(nowDate)
    this.setData({
      currentDate: currentDate
    })
    this.setData({
      currentWeek: currentWeek
    })
    var tempArray = [];
    for (var i = 1; i < 8; i++) {
      let nextDate = new Date(tempDate.setDate(tempDate.getDate() + 1))
      var nextMonth = nextDate.getMonth() + 1 > 9 ? (nextDate.getMonth() + 1) : '0' + (nextDate.getMonth() + 1)
      let nextDay = tempDate.getDate() > 9 ? tempDate.getDate() : '0' + tempDate.getDate()
      var visitDate = nextDate.getFullYear() + '-' + nextMonth + '-' + nextDay
      var selected = false
      if (i == 1) {
        selected = true
        this.setData({
          selectedDate: visitDate
        })
      }
      tempArray.push({
        date: nextDay,
        week: format.getWeek(nextDate),
        visitDate: visitDate,
        selected: selected,
        index: i - 1
      })
    }
    this.setData({
      dateArray: tempArray
    });
  },
  selectMember: function() {
    wx.navigateTo({
      url: '../family/family?type=1',
    })

  },
  selectDate: function(e) {
    var item = e.currentTarget.dataset.dateItem
    item.selected = true
    this.setData({
      selectedDate: item.visitDate
    })
    var tempArray = this.data.dateArray
    for (var index in this.data.dateArray) {
      if (tempArray[index].selected) {
        tempArray[index].selected = false
      }
    }
    tempArray.splice(item.index, 1, item);
    this.setData({
      dateArray: tempArray
    })
    this.getDoctorList(item.visitDate)
  },

  bindRegionChange: function(e) {
    this.setData({
      selectedHospital: {}
    })
    var index = e.detail.value
    var selectedCity = this.data.cityArray[index]
    this.setData({
      selectedCity: selectedCity
    })
    this.getHospital(selectedCity.cityCode)
  },
  bindHospitalChange: function(e) {
    var index = e.detail.value
    var selectedHospital = this.data.hospitalArray[index]
    this.setData({
      selectedHospital: selectedHospital
    })
    this.getDoctorList(this.data.selectedDate)
  },
  getDoctorList: function(date) {
    var that = this
    if (!that.isValidHospital()) {
      return
    }
    var hospitalId = that.data.selectedHospital.hospitalId
    req.getRequest('registeres/doctorSchedules/byPatient', {
      hospitalId: hospitalId,
      visitDate: date
    }).then(res => {
      if (res === 'loginSuccess') {
        that.getDoctorList(date)
        return
      }
      if (res.data.returnObject.length > 0) {
        for (var i in res.data.returnObject) {
          var doctor = res.data.returnObject[i]
          if (doctor.doctorSpecialty == null || doctor.doctorSpecialty == '') {
            doctor.doctorSpecialty = '暂未填写'
          }
          doctor.doctorTitle = res.data.returnObject[i].doctorTitle != null ? res.data.returnObject[i].doctorTitle : ''
          doctor.avatar = util.download(doctor.avatar)
          var total = res.data.returnObject[i].total
          var used = res.data.returnObject[i].used
          var unUsed = total - used
          if (unUsed > 0) {
            doctor.status = '有号'
          } else {
            doctor.status = '无号'
          }
        }
      }
      that.setData({
        doctorList: res.data.returnObject
      })
    })

  },
  isValidHospital: function() {
    if (!this.data.selectedCity.cityCode) {
      wx.showToast({
        title: '请选择城市!',
        icon: 'none',
        duration: 2000
      })
      return false
    } else if (!this.data.selectedHospital.hospitalId) {
      wx.showToast({
        title: '请选择医院!',
        icon: 'none',
        duration: 2000
      })
      return false
    } else {
      return true
    }
  },
  isValid: function() {
    if (!this.data.selectMember.id) {
      wx.showToast({
        title: '请选择家庭成员!',
        icon: 'none',
        duration: 2000
      })
      return false
    } else {
      return true
    }
  },
  selectedDoctor: function(e) {
    if (!this.isValid()) {
      return
    }
    var selectedDoctor = e.currentTarget.dataset.doctorItem
    wx.navigateTo({
      url: '../chooseDoctor/chooseDoctor?selectedDoctorId=' + selectedDoctor.doctorId + '&selectedDate=' + this.data.selectedDate + '&selectedMemberId=' + this.data.selectMember.id
    })
  },
  upper: function() {
    var self = this;
    setTimeout(function() {
      console.log('下拉刷新');
      var date = new Date();
      self.setData({
        refreshTime: date.toLocaleTimeString(),
        hideHeader: false
      })
    }, 300);
  },
  lower: function() {
    wx.showToast({
      title: '加载中',
      icon: 'loading'
    });
    console.log('lower')

  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    this.getServerTime()
    // this.dealDate();
    var date = new Date();
    this.setData({
      refreshTime: date.toLocaleTimeString()
    });
    var that = this;
    wx.getSystemInfo({
      success: function(res) {
        console.log(res);
        // 可使用窗口宽度、高度
        console.log('height=' + res.windowHeight);
        console.log('width=' + res.windowWidth);
        // 计算主体部分高度,单位为px
        that.setData({
          // second部分高度 = 利用窗口可使用高度 - first部分高度（这里的高度单位为px，所有利用比例将300rpx转换为px）
          second_height: res.windowHeight - res.windowWidth / 750 * 480
        })
      }
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },
  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {

  }
})