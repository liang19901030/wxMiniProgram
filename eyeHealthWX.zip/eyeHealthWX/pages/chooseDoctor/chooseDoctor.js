// pages/chooseDoctor/chooseDoctor.js
import util from '../../utils/util.js'
import req from '../../utils/service.js'

Page({

  /**
   * 页面的初始数据
   */
  data: {
    winWidth: 0,
    winHeight: 0,
    currentTab: 0,
    page: 0,
    scrollTop: 0,
    swiper_height: 0,
    coPay: 0,
    doctorId: '',
    selectedMemberId: '',
    doctor: {},
    selectedDateArr: [],
    moreDateArr: [],
    selectedDate: '',
    selectedDateDic: {},
    timeInterval: '',
  },
  getDoctorInfo: function(doctorId) {
    var that = this
    req.getRequest('registeres/detail/' + doctorId).then(res => {
      if (res === 'loginSuccess') {
        that.getDoctorInfo(doctorId)
        return
      }
      res.data.returnObject.avatar = util.download(res.data.returnObject.doctorAvatar)
      if (res.data.returnObject.introduction == null || res.data.returnObject.introduction == '') {
        res.data.returnObject.introduction = '暂未填写'

      }
      if (res.data.returnObject.doctorSpecialty == null || res.data.returnObject.doctorSpecialty == '') {
        res.data.returnObject.doctorSpecialty = '暂未填写'

      }
      var selectedTempArray = []
      var moreTempArray = []
      for (var i in res.data.returnObject.doctorScheduleList) {
        var doctor = res.data.returnObject.doctorScheduleList[i]
        doctor.selected = false
        doctor.doctorTitle = res.data.returnObject.doctorTitle != null ? res.data.returnObject.doctorTitle : ''
        doctor.departmentName = res.data.returnObject.departmentName != null ? res.data.returnObject.departmentName : ''

        var total = doctor.total
        var used = doctor.used
        var unUsed = total - used
        doctor.unUsed = unUsed
        if (doctor.visitDate == that.data.selectedDate) {
          selectedTempArray.push(doctor)
        } else {
          moreTempArray.push(doctor)
        }
      }
      for (var i in selectedTempArray) {
        if (selectedTempArray[i].unUsed != 0) {
          selectedTempArray[i].selected = true
          that.setData({
            selectedDateDic: selectedTempArray[i]
          })
          break
        }
      }
      that.setData({
        coPay: selectedTempArray[0].coPay
      })
      that.setData({
        doctor: res.data.returnObject
      })
      that.setData({
        selectedDateArr: selectedTempArray
      })
      that.setData({
        moreDateArr: moreTempArray
      })
    })
  },

  chooseDate: function(e) {
    var dateIndex = e.currentTarget.dataset.dateIndex
    var item = this.data.selectedDateArr[dateIndex]
    item.selected = true
    this.setData({
      selectedDateDic: item
    })
    var tempArray = this.data.selectedDateArr
    for (var index in this.data.selectedDateArr) {
      if (tempArray[index].selected && tempArray[index] !== item) {
        tempArray[index].selected = false
      }
    }
    for (var index in this.data.moreDateArr) {
      this.data.moreDateArr[index].selected = false
    }
    this.setData({
      moreDateArr: this.data.moreDateArr
    })
    this.setData({
      selectedDateArr: tempArray
    })
  },

  chooseMoreDate: function(e) {
    var dateIndex = e.currentTarget.dataset.dateIndex
    var item = this.data.moreDateArr[dateIndex]
    item.selected = true
    this.setData({
      selectedDateDic: item
    })
    var tempArray = this.data.moreDateArr
    for (var index in this.data.moreDateArr) {
      if (tempArray[index].selected && tempArray[index] !== item) {
        tempArray[index].selected = false
      }
    }
    for (var index in this.data.selectedDateArr) {
      this.data.selectedDateArr[index].selected = false
    }
    this.setData({
      selectedDateArr: this.data.selectedDateArr
    })
    this.setData({
      moreDateArr: tempArray
    })
  },
  order: function() {
    wx.navigateTo({
      url: '../orderPay/orderPay?selectedDateDic=' + JSON.stringify(this.data.selectedDateDic) + '&doctorAvatar=' + this.data.doctor.doctorAvatar + '&doctorId=' + this.data.doctor.doctorId + '&doctorName=' + this.data.doctor.doctorName + '&doctorTitle=' + this.data.doctor.doctorTitle + '&hospitalName=' + this.data.doctor.hospitalName + '&departmentName=' + this.data.doctor.departmentName + '&selectedMemberId=' + this.data.selectedMemberId
    })
  },
  /**
   *  滑动切换tab
   */
  bindChange: function(e) {
    var that = this;
    that.goTop()
    that.setData({
      currentTab: e.detail.current
    })
    if (e.detail.current === 0) {} else {}
  },
  /**
   *  点击切换tab
   */
  switchNav: function(e) {
    var that = this;
    if (that.data.currentTab === e.target.dataset.current) {
      return false;
    } else {
      that.goTop()
      that.setData({
        currentTab: e.target.dataset.current
      })
    }
  },
  goTop: function() {
    this.setData({
      scrollTop: 0,
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    var that = this;
    that.setData({
      doctorId: options.selectedDoctorId, //options为页面路由过程中传递的参数
      selectedMemberId: options.selectedMemberId,
      selectedDate: options.selectedDate
    })
    wx.getSystemInfo({
      success: function(res) {
        that.setData({
          winWidth: res.windowWidth,
          winHeight: res.windowHeight,
          swiper_height: res.windowHeight - res.windowWidth / 750 * 428
        })
      },
    });
    that.getDoctorInfo(that.data.doctorId)
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {

  }
})