import config from './config.js'

function download(path, style) {
  if (!path) return "";
  var styleUri = '';
  if (style == '' || style == undefined) {
    styleUri += "?x-oss-process=image/resize,m_fixed,w_300"
  } else {
    styleUri += "?x-oss-process=image/resize,m_fixed," + style
  }
  console.log(config.server.api + path + styleUri)
  return config.server.ossDownload + path + styleUri;
}

function formatReportType(type) {
  var typeStr = ''
  switch (type) {
    case 1:
      typeStr = '咨询报告'
      break
    case 2:
      typeStr = '会诊报告'
      break
    case 3:
      typeStr = '诊断报告'
      break
  }
  return typeStr
}

function formatOrderStatus(type) {
  var statusStr = ''
  switch (type) {
    case 1:
      statusStr = '待支付'
      break
    case 2:
      statusStr = '待就诊'
      break
    case 3:
      statusStr = '已就诊'
      break
    case 4:
      statusStr = '未就诊'
      break
    case 5:
      statusStr = '支付超时'
      break
    case 6:
      statusStr = '取消预约'
      break
  }
  return statusStr
}

function test(a) {
  console.log(a)
}

module.exports = {
  test: test,
  download: download,
  formatReportType: formatReportType,
  formatOrderStatus: formatOrderStatus,
}